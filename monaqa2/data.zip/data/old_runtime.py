import numpy as np
from monaqa2.mcmc.search import search_monotone

ALLOWED_DEVICES = {"cpu", "gpu", "fpga"}
ALLOWED_ARITHMETIC_TYPES = {"HYBRID", "FIXED_POINT"}


def _validate_arithmetic_type(arithmetic_type: str) -> str:
    """Return a validated arithmetic type.

    :param arithmetic_type: Arithmetic implementation name.
    :return: The validated arithmetic implementation name.
    """
    if arithmetic_type not in ALLOWED_ARITHMETIC_TYPES:
        raise ValueError(f"Unknown arithmetic_type={arithmetic_type!r}. Allowed: {ALLOWED_ARITHMETIC_TYPES}")
    return arithmetic_type


def _validate_randomized_grid(k_randomized_grid: int) -> int:
    """Return a non-negative integer grid level; zero selects a fixed proposal."""
    if isinstance(k_randomized_grid, (bool, np.bool_)) or not isinstance(k_randomized_grid, (int, np.integer)) or k_randomized_grid < 0:
        raise ValueError("k_randomized_grid must be a non-negative integer.")
    return int(k_randomized_grid)


def cpu_local_step(n: int | float) -> float:
    """Return the fitted CPU time for one local classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one local update.
    """
    # local/op: 5.959e-09 + 1.429e-10 n
    return 5.959e-09 + 1.429e-10 * n


def cpu_uniform_step(n: int | float) -> float:
    """Return the fitted CPU time for one uniform classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one uniform update.
    """
    # uniform/op: 0.000e+00 + 1.173e-08 n + 6.964e-11 n^2
    return 1.173e-08 * n + 6.964e-11 * n**2


def gpu_local_step(n: int | float) -> float:
    """Return the fitted GPU time for one local classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one local update.
    """
    # local/op: 7.837e-07 + 1.459e-09 n
    return 7.837e-07 + 1.459e-09 * n


def gpu_uniform_step(n: int | float) -> float:
    """Return the fitted GPU time for one uniform classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one uniform update.
    """
    # uniform/op: 0.000e+00 + 0.000e+00 n + 2.215e-10 n^2
    return 2.215e-10 * n**2


def fpga_local_step(n: int | float) -> float:
    """Return the fitted FPGA time for one local classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one local update.
    """
    # 0.267900 + 0.001800 log2(N) [μs, multiply by 10^{-6}]
    return (0.267900 + 0.001800 * np.log2(n)) * 1e-6


def fpga_uniform_step(n: int | float) -> float:
    """Return the fitted FPGA time for one uniform classical Metropolis step.

    :param n: Number of spins.
    :return: Runtime in seconds for one uniform update.
    """
    # 0.254100 + 0.004200 log2(N) [μs, multiply by 10^{-6}]
    return (0.254100 + 0.004200 * np.log2(n)) * 1e-6


def split_quantum_error_budget(eps_TV: float) -> tuple[float, float, float, float]:
    """Split the target total-variation error into four resource budgets.

    :param eps_TV: Desired final total-variation distance error.
    :return: Tuple ``(eps_SF, eps_MS, eps_FLT, eps_W_budget)`` for surface-code failures, magic-state failures, spectral-filter approximation, and walk-implementation error.
    """
    eps_SF = eps_TV / 4.0
    eps_MS = eps_TV / 4.0
    eps_FLT = eps_TV / 4.0
    eps_W_budget = eps_TV / 4.0
    return eps_SF, eps_MS, eps_FLT, eps_W_budget


def rotated_surface_code_distance(spacetime_volume: int | float, physical_error_rate: float, eps_SF: float) -> float:
    """Return the smallest odd rotated-surface-code distance satisfying the surface-code budget.

    :param spacetime_volume: Logical spacetime volume, equal to logical time times logical space.
    :param physical_error_rate: Physical Clifford error rate.
    :param eps_SF: Error budget assigned to surface-code logical failures.
    :return: Smallest odd code distance ``d >= 3`` satisfying the error model.
    """
    def distance(index: int) -> int:
        return 2 * index + 3

    def total_error(index: int) -> float:
        d = distance(index)
        logical_error_per_round = 0.03 * (100 * physical_error_rate) ** ((d + 1.0) / 2.0)
        return spacetime_volume * logical_error_per_round

    index = search_monotone(total_error, lambda error: error - eps_SF, 0, 1_000_000, info="rotated_surface_code_distance")
    return float(distance(index))


def rotated_surface_code_time(logical_time: int | float, logical_space: int | float, physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, eps_SF: float) -> float:
    """Return the physical runtime of a logical computation under the rotated-surface-code model.

    :param logical_time: Logical depth in tile-time steps.
    :param logical_space: Logical space in surface-code tiles.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param eps_SF: Error budget assigned to surface-code logical failures.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    spacetime_volume = logical_time * logical_space
    d = rotated_surface_code_distance(spacetime_volume, physical_error_rate, eps_SF)
    logical_cycle_time = d * (4 * physical_operation_time + physical_measurement_time)
    return logical_time * logical_cycle_time


def _ceil_log2(x: int | float) -> int:
    """Return ``ceil(log2(x))`` for a positive argument."""
    x = float(x)
    if not np.isfinite(x) or x <= 0.0:
        raise ValueError(f"Expected a finite positive value, got {x}.")
    return int(np.ceil(np.log2(x)))


def _calculate_auxiliary_quantum_circuit_vars(n: int | float, eps_W: float, beta: float) -> tuple[float, float, int, int, int, int]:
    """Return the parameters entering the fixed-point walk-resource estimate.

    The coefficient precision retains the previous convention:
    ``S = 1 + log2(n) + log2(1/eps_W)``, ``F = ceil(3.5*S)``, ``W = F+1``.
    The rotation coin needs neither a polynomial degree nor a tail cutoff.

    :param n: Number of spins.
    :param eps_W: Error budget for one implementation of ``W`` or ``W-dagger``.
    :param beta: Inverse temperature for the current annealing step.
    :return: Tuple ``(S, M, W, ell_W, s_SK, ell_n)``.
    """
    n = float(n)
    beta = float(beta)
    eps_W = float(eps_W)

    if not np.isfinite(n) or n < 3.0:
        raise ValueError(f"Invalid n={n}. Expected n >= 3.")
    if not np.isfinite(beta) or beta < 0.0:
        raise ValueError(f"Invalid beta={beta}. Expected beta >= 0.")
    if not np.isfinite(eps_W) or not (0.0 < eps_W < 1.0):
        raise ValueError(f"Invalid eps_W={eps_W}. Expected 0 < eps_W < 1.")

    ell_n = _ceil_log2(n)
    S = 1.0 + np.log2(n) + np.log2(1.0 / eps_W)
    F = int(np.ceil(3.5 * S))
    W = F + 1
    ell_W = _ceil_log2(W)

    M = n + n * (n - 1.0) / 2.0
    s_SK = int(np.ceil(np.log(2.0 * M) / np.log(3.0 / 2.0)))
    return S, M, W, ell_W, s_SK, ell_n


def fixed_point_arithmetic_circuit(n: int | float, eps_W: float, beta: float) -> tuple[float, float]:
    """Return non-Clifford depth and qubits for FixedPointArithmetic.

    Each controlled Ry decomposes into two sequential Rz rotations. The W
    bit/coin pairs are disjoint, so all pairs run in parallel: two rotation
    layers and 2W rotations, or zero at beta=0. As in the other resource
    estimates, an arbitrary Rz counts as one non-Clifford layer; synthesis
    into discrete T gates and factory throughput are not modeled here.
    The existing Wallace-tree/final-carry and positive-selector costs are
    retained, with both arithmetic blocks computed and uncomputed.
    """
    _, M, W, _, s_SK, _ = _calculate_auxiliary_quantum_circuit_vars(n, eps_W, beta)

    delta_depth = 18 * s_SK + 18 * W
    positive_depth = 3
    rotation_depth = 0 if beta == 0.0 else 2
    boltz_depth = rotation_depth + 2 * delta_depth + 2 * positive_depth
    boltz_qubits = 2 * n + 6 * W * M - 2 * M + W + 1
    return float(boltz_depth), float(boltz_qubits)


def _fixed_point_walk_blocks(n: int | float, eps_W: float, beta: float) -> tuple[float, float, float, float, float, float]:
    """Return fixed-point coin, reflection, and accept-path resources."""
    _, _, W, ell_W, _, _ = _calculate_auxiliary_quantum_circuit_vars(n, eps_W, beta)
    boltz_depth, boltz_qubits = fixed_point_arithmetic_circuit(n, eps_W, beta)

    reflection_depth = 14 * _ceil_log2(n + W - 1) - 10
    reflection_qubits = 2 * n + W + 2

    accept_depth = 28 * ell_W - 11
    accept_qubits = 3 * n + W

    return boltz_depth, boltz_qubits, reflection_depth, reflection_qubits, accept_depth, accept_qubits


def _calculate_auxiliary_hybrid_circuit_vars(n: int | float, eps_W: float, beta: float) -> tuple:
    """Retain the original hybrid precision, cutoff, and QSP-degree model."""
    S, M, W, ell_W, s_SK, ell_n = _calculate_auxiliary_quantum_circuit_vars(n, eps_W, beta)
    lambda_scale = 2.0 * float(n)**1.5 / np.sqrt(np.pi)
    eps_tail = float(eps_W) / 2.0
    if beta <= 0.0 or lambda_scale <= 0.0:
        c = 0
    else:
        cutoff_argument = beta * lambda_scale / (2.0 * np.log(1.0 / eps_tail))
        c_raw = int(np.floor(np.log2(cutoff_argument))) if cutoff_argument > 0.0 else 0
        c = max(0, min(W - 1, c_raw))
    ell_c = _ceil_log2(c) if c >= 1 else 0
    d_hyb = int(np.ceil(0.5 * beta * lambda_scale * 2.0**(-c) + np.log(2.0 / eps_W) + 1.0))
    return S, M, W, ell_W, lambda_scale, s_SK, c, ell_c, d_hyb, ell_n


def _hybrid_cutoff_depth(W: int, c: int, ell_c: int) -> int:
    """Return the original hybrid cutoff-tail block depth."""
    if c == 0:
        return 0
    if c == 1:
        return 3 * (W - 2)
    if c == 2:
        return 3 + 3 * (W - 3)
    return 14 * ell_c - 10 + 3 * (W - c - 1)


def _hybrid_walk_blocks(n: int | float, eps_W: float, beta: float) -> tuple[float, float, float, float, float, float]:
    """Return the original hybrid coin, reflection, and accept-path resources."""
    S, M, W, ell_W, _, s_SK, c, ell_c, d_hyb, _ = _calculate_auxiliary_hybrid_circuit_vars(n, eps_W, beta)
    delta_depth = 18 * s_SK + 18 * W
    positive_depth = 3
    cutoff_depth = _hybrid_cutoff_depth(W, c, ell_c)
    sqrt_exp_depth = d_hyb * (54 * ell_W - 18) + 3
    boltz_depth = sqrt_exp_depth + 2 * delta_depth + 2 * positive_depth + 2 * cutoff_depth
    boltz_qubits = 2 * n + 6 * W * M - 2 * M + 2
    reflection_depth = 14 * _ceil_log2(n + W) - 10
    reflection_qubits = 2 * n + W + 3
    accept_depth = 28 * _ceil_log2(W + 1) - 11
    accept_qubits = 3 * n + W + 1
    return boltz_depth, boltz_qubits, reflection_depth, reflection_qubits, accept_depth, accept_qubits


def hybrid_arithmetic_circuit(n: int | float, eps_W: float, beta: float) -> tuple[float, float]:
    """Return the original QSP-based hybrid coin's depth and logical qubits."""
    depth, qubits, *_ = _hybrid_walk_blocks(n, eps_W, beta)
    return float(depth), float(qubits)


def _quantum_walk_circuit(n: int | float, eps_W: float, beta: float, proposal_depth: int | float, proposal_qubits: int | float, arithmetic_type: str) -> tuple[float, float]:
    """Combine the proposal with the selected arithmetic and walk reflections."""
    arithmetic_type = _validate_arithmetic_type(arithmetic_type)
    blocks = _hybrid_walk_blocks if arithmetic_type == "HYBRID" else _fixed_point_walk_blocks
    boltz_depth, boltz_qubits, reflection_depth, reflection_qubits, accept_depth, accept_qubits = blocks(n, eps_W, beta)
    logical_depth = 2 * proposal_depth + 2 * boltz_depth + reflection_depth + accept_depth
    logical_qubits = max(proposal_qubits, boltz_qubits, reflection_qubits, accept_qubits)
    return float(logical_depth), float(logical_qubits)


def quantum_walk_local_circuit(n: int | float, eps_W: float, beta: float, arithmetic_type: str = "HYBRID") -> tuple[float, float]:
    """Return resources for one local-proposal Szegedy walk application.

    :param n: Number of spins.
    :param eps_W: Error budget for one implementation of ``W`` or ``W-dagger``.
    :param beta: Inverse temperature for the current annealing step.
    :param arithmetic_type: Arithmetic implementation. Choose ``"HYBRID"`` or ``"FIXED_POINT"`` (default).
    :return: Tuple ``(logical_depth, logical_qubits)`` for one walk application.
    """
    proposal_depth = 2 * _ceil_log2(n)
    proposal_qubits = 2 * n
    return _quantum_walk_circuit(n, eps_W, beta, proposal_depth, proposal_qubits, arithmetic_type)


def quantum_walk_uniform_circuit(n: int | float, eps_W: float, beta: float, arithmetic_type: str = "HYBRID") -> tuple[float, float]:
    """Return resources for one uniform-proposal Szegedy walk application.

    :param n: Number of spins.
    :param eps_W: Error budget for one implementation of ``W`` or ``W-dagger``.
    :param beta: Inverse temperature for the current annealing step.
    :param arithmetic_type: Arithmetic implementation. Choose ``"HYBRID"`` or ``"FIXED_POINT"`` (default).
    :return: Tuple ``(logical_depth, logical_qubits)`` for one walk application.
    """
    proposal_depth = 0
    proposal_qubits = 2 * n
    return _quantum_walk_circuit(n, eps_W, beta, proposal_depth, proposal_qubits, arithmetic_type)


def quantum_walk_qemc_circuit(n: int | float, eps_W: float, beta: float, num_trotter_steps: int = 50, arithmetic_type: str = "HYBRID", k_randomized_grid: int = 0) -> tuple[float, float]:
    """Return resources for one Hamiltonian-simulation-proposal Szegedy walk.

    The randomized proposal implements H_tf = (1-gamma) H - gamma sum_i X_i.
    Both Ising and mixer angles contain products of the time and gamma bits.
    Their expansion has one ordinary, 2*k singly controlled, and k**2 doubly
    controlled rotations per Pauli term. The retained Clifford+Rz model uses
    depths (1, 2, 4) for Z rotations and (1, 2, 6) for X rotations. Negating
    mixer angles changes neither these bounds nor the workspace allocation.

    :param n: Number of spins.
    :param eps_W: Error budget for one implementation of ``W`` or ``W-dagger``.
    :param beta: Inverse temperature for the current annealing step.
    :param num_trotter_steps: Number of Trotter steps used by the proposal.
    :param arithmetic_type: Arithmetic implementation. Choose ``"HYBRID"`` or ``"FIXED_POINT"`` (default).
    :param k_randomized_grid: Randomized-grid level. Use 0 for a single fixed choice of ``(t, gamma)``.
    :return: Tuple ``(logical_depth, logical_qubits)`` for one walk application.
    """
    if num_trotter_steps < 1:
        raise ValueError("Use num_trotter_steps >= 1.")
    r = num_trotter_steps
    k = _validate_randomized_grid(k_randomized_grid)

    if k == 0:
        # Single fixed choice of (t, gamma).
        proposal_depth = r * (n + 3)
        proposal_qubits = 2 * n
    else:
        # Coherent randomized proposal over a 2^k x 2^k grid.
        # t*(1-gamma) and -t*gamma both include time--gamma cross terms.
        ising_layer_depth = 1 + (2 * k) * 2 + k**2 * 4
        mixer_layer_depth = 1 + (2 * k) * 2 + k**2 * 6
        # At most n ZZ matchings plus local Z; adjacent mixer halves merge.
        proposal_depth = r * (n + 1) * ising_layer_depth + (r + 1) * mixer_layer_depth
        proposal_qubits = 2 * n * (k + 1)

    return _quantum_walk_circuit(n, eps_W, beta, proposal_depth, proposal_qubits, arithmetic_type)


def get_time_direct_enumeration(n: int):
    # return 1.504584e-07 * (2**n)
    return 6.323731e-10 * (n**2) * (2**n)


def get_annealing_time_classical_walk_local(n: int | float, vec_queries: list[float], device: str = "cpu") -> float:
    """Return the classical annealing runtime for local Metropolis updates.

    :param n: Number of spins.
    :param vec_queries: Number of classical update queries per annealing step.
    :param device: Classical device model, one of ``"cpu"``, ``"gpu"``, or ``"fpga"``.
    :return: Total runtime in seconds.
    """
    assert device in ALLOWED_DEVICES, f"Device {device} unknown. Allowed: {ALLOWED_DEVICES}"
    if device == "cpu":
        return sum(vec_queries) * cpu_local_step(n)
    if device == "gpu":
        return sum(vec_queries) * gpu_local_step(n)
    if device == "fpga":
        return sum(vec_queries) * fpga_local_step(n)


def get_annealing_time_classical_walk_uniform(n: int | float, vec_queries: list[float], device: str = "cpu") -> float:
    """Return the classical annealing runtime for uniform Metropolis updates.

    :param n: Number of spins.
    :param vec_queries: Number of classical update queries per annealing step.
    :param device: Classical device model, one of ``"cpu"``, ``"gpu"``, or ``"fpga"``.
    :return: Total runtime in seconds.
    """
    assert device in ALLOWED_DEVICES, f"Device {device} unknown. Allowed: {ALLOWED_DEVICES}"
    if device == "cpu":
        return sum(vec_queries) * cpu_uniform_step(n)
    if device == "gpu":
        return sum(vec_queries) * gpu_uniform_step(n)
    if device == "fpga":
        return sum(vec_queries) * fpga_uniform_step(n)


def get_annealing_time_classical_walk_qemc(n: int | float, vec_queries: list[float], physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, eps_SF: float, num_trotter_steps: int = 50) -> float:
    """Return the surface-code runtime for a QEMC proposal used inside a classical annealing schedule.

    :param n: Number of spins.
    :param vec_queries: Number of QEMC proposal queries per annealing step.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param eps_SF: Error budget assigned to surface-code logical failures.
    :param num_trotter_steps: Number of Trotter steps used by the QEMC proposal.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    total_time = 0
    for queries in vec_queries:
        logical_time_per_query = num_trotter_steps * (n + 3)
        logical_space = n
        physical_time = queries * rotated_surface_code_time(logical_time_per_query, logical_space, physical_operation_time, physical_measurement_time, physical_error_rate, eps_SF)
        total_time += physical_time
    return total_time


# @interpolation_cache(monaqa2.data.filename.CACHE_PHASE_GAP_FACTOR_FILE)
# def phase_gap_factor(spectral_gap: float) -> float:
#     """Return the inverse phase gap of a Szegedy walk.
# 
#     :param spectral_gap: Classical spectral gap ``delta``.
#     :return: ``1 / arccos(1 - delta)``, evaluated as ``1 / (2 asin(sqrt(delta / 2)))`` for numerical stability.
#     """
#     with mp.workdps(100):
#         g = mp.mpf(spectral_gap)
#         # 1.0 is wrapped in mp.mpf to force mpmath high-precision division
#         # MUUUUCH SAFER THAN arccos(1 - g)
#         result = mp.mpf(1) / (2 * mp.asin(mp.sqrt(g / 2)))
#         return float(result)

def phase_gap_factor(spectral_gap: float | str | np.longdouble) -> np.longdouble:
    """Return ``1 / arccos(1 - delta)``, computed stably.

    :param spectral_gap: Classical spectral gap ``delta``.
    :return: Inverse Szegedy phase gap.
    """
    g = np.longdouble(spectral_gap)
    if not np.isfinite(g) or g <= np.longdouble(0) or g > np.longdouble(1):
        raise ValueError(f"Invalid spectral_gap={spectral_gap}. Expected 0 < spectral_gap <= 1.")
    return np.longdouble(1) / (
        np.longdouble(2) * np.arcsin(np.sqrt(g / np.longdouble(2)))
    )

def spectral_filter_polynomial_degree(spectral_gap: float, eps_filter: float) -> float:
    """Return the polynomial degree for one QSVT spectral filter.

    :param spectral_gap: Spectral gap of the Markov-chain discriminant matrix at the current annealing step.
    :param eps_filter: Leakage budget assigned to this single spectral filter.
    :return: Degree of the QSVT spectral-filter polynomial.
    """
    return 2 * np.log2(1.0 / eps_filter) * phase_gap_factor(spectral_gap)


def spectral_filter_polynomial_degree_list(spectral_gaps: list[float], eps_FLT: float, overlap: float = 1.0 / np.e) -> list[float]:
    """Return the QSVT spectral-filter degree for each annealing step.

    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param eps_FLT: Total error budget assigned to all spectral-filter polynomial approximations.
    :param overlap: Lower bound on the squared overlap between consecutive annealing states.
    :return: List of polynomial degrees, one for each spectral gap.
    """
    num_filters = len(spectral_gaps)
    num_zeno_filters = num_filters * (1.0 + 1.0 / overlap)
    eps_filter = eps_FLT / num_zeno_filters
    return [spectral_filter_polynomial_degree(spectral_gap, eps_filter) for spectral_gap in spectral_gaps]


def get_scheduled_filter_queries(degree_filters: list[float], overlap: float = 1.0 / np.e) -> list[float]:
    """Return the expected number of walk queries per annealing step after Zeno-rewind repetitions.

    :param degree_filters: Degree of each unique QSVT spectral filter.
    :param overlap: Lower bound on the squared overlap between consecutive annealing states.
    :return: Expected number of calls to ``W`` or ``W-dagger`` contributed by each annealing step.
    """
    zeno_overhead = 1.0 + 1.0 / overlap
    return [zeno_overhead * degree for degree in degree_filters]


def get_quantum_annealing_error_budget(eps_TV: float, spectral_gaps: list[float], zeno_overlap_probability: float = 1.0 / np.e) -> dict[str, float | list[float]]:
    """Return the error budget and query counts for the quantum annealing schedule.

    :param eps_TV: Desired final total-variation distance error.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :return: Dictionary containing the four error budgets, QSVT degrees, expected queries per step, total expected queries, and per-walk error ``eps_W``.
    """
    eps_SF, eps_MS, eps_FLT, eps_W_budget = split_quantum_error_budget(eps_TV)
    degree_filters = spectral_filter_polynomial_degree_list(spectral_gaps, eps_FLT, zeno_overlap_probability)
    queries_per_step = get_scheduled_filter_queries(degree_filters, zeno_overlap_probability)
    total_queries = float(sum(queries_per_step))
    eps_W = eps_W_budget / total_queries
    return {
        "eps_TV": float(eps_TV),
        "eps_SF": eps_SF,
        "eps_MS": eps_MS,
        "eps_FLT": eps_FLT,
        "eps_W_budget": eps_W_budget,
        "eps_W": eps_W,
        "degree_filters": degree_filters,
        "queries_per_step": queries_per_step,
        "total_queries": total_queries,
    }


def _get_annealing_time_quantum_walk(n: int | float, eps_TV: float, betas: list[float], spectral_gaps: list[float], physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, circuit_fn, zeno_overlap_probability: float = 1.0 / np.e, arithmetic_type: str = "HYBRID") -> float:
    """Return the surface-code runtime for a quantum annealing schedule.

    :param n: Number of spins.
    :param eps_TV: Desired final total-variation distance error.
    :param betas: Inverse temperatures along the annealing schedule.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param circuit_fn: Function returning one-walk logical resources for a selected proposal rule.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :param arithmetic_type: Arithmetic implementation, ``"HYBRID"`` or ``"FIXED_POINT"``.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    budget = get_quantum_annealing_error_budget(eps_TV, spectral_gaps, zeno_overlap_probability)
    eps_SF = budget["eps_SF"]
    eps_W = budget["eps_W"]
    queries_per_step = budget["queries_per_step"]

    logical_time = 0
    logical_space = 0
    for beta, queries in zip(betas, queries_per_step):
        walk_time, walk_space = circuit_fn(n, eps_W, beta, arithmetic_type)
        logical_time += queries * walk_time
        logical_space = max(logical_space, walk_space)

    return rotated_surface_code_time(logical_time, logical_space, physical_operation_time, physical_measurement_time, physical_error_rate, eps_SF)


def get_annealing_time_quantum_walk_local(n: int, eps_TV: float, betas: list[float], spectral_gaps: list[float], physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, *, zeno_overlap_probability: float = 1.0 / np.e, num_trotter_steps: int = 50, arithmetic_type: str = "HYBRID") -> float:
    """Return the surface-code runtime for quantum annealing with local-proposal Szegedy walks.

    :param n: Number of spins.
    :param eps_TV: Desired final total-variation distance error.
    :param betas: Inverse temperatures along the annealing schedule.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :param num_trotter_steps: Unused for local proposals; kept for signature compatibility.
    :param arithmetic_type: Arithmetic implementation, ``"HYBRID"`` or ``"FIXED_POINT"``.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    return _get_annealing_time_quantum_walk(n, eps_TV, betas, spectral_gaps, physical_operation_time, physical_measurement_time, physical_error_rate, quantum_walk_local_circuit, zeno_overlap_probability, arithmetic_type)


def get_annealing_time_quantum_walk_uniform(n: int, eps_TV: float, betas: list[float], spectral_gaps: list[float], physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, *, zeno_overlap_probability: float = 1.0 / np.e, num_trotter_steps: int = 50, arithmetic_type: str = "HYBRID") -> float:
    """Return the surface-code runtime for quantum annealing with uniform-proposal Szegedy walks.

    :param n: Number of spins.
    :param eps_TV: Desired final total-variation distance error.
    :param betas: Inverse temperatures along the annealing schedule.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :param num_trotter_steps: Unused for uniform proposals; kept for signature compatibility.
    :param arithmetic_type: Arithmetic implementation, ``"HYBRID"`` or ``"FIXED_POINT"``.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    return _get_annealing_time_quantum_walk(n, eps_TV, betas, spectral_gaps, physical_operation_time, physical_measurement_time, physical_error_rate, quantum_walk_uniform_circuit, zeno_overlap_probability, arithmetic_type)


def get_annealing_time_quantum_walk_qemc(n: int, eps_TV: float, betas: list[float], spectral_gaps: list[float], physical_operation_time: float, physical_measurement_time: float, physical_error_rate: float, *, zeno_overlap_probability: float = 1.0 / np.e, num_trotter_steps: int = 50, arithmetic_type: str = "HYBRID", k_randomized_grid: int = 0) -> float:
    """Return the surface-code runtime for quantum annealing with QEMC-proposal Szegedy walks.

    :param n: Number of spins.
    :param eps_TV: Desired final total-variation distance error.
    :param betas: Inverse temperatures along the annealing schedule.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param physical_operation_time: Time for one physical operation.
    :param physical_measurement_time: Time for one physical measurement.
    :param physical_error_rate: Physical Clifford error rate.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :param num_trotter_steps: Number of Trotter steps used by the QEMC proposal.
    :param arithmetic_type: Arithmetic implementation, ``"HYBRID"`` or ``"FIXED_POINT"``.
    :param k_randomized_grid: Non-negative grid level; 0 uses one fixed (t, gamma), positive k uses a 2**k by 2**k grid. Default 2.
    :return: Physical runtime in the same time unit as the physical operation and measurement times.
    """
    k_randomized_grid = _validate_randomized_grid(k_randomized_grid)

    def circuit_fn(n_local: int | float, eps_W: float, beta: float, arithmetic_type_local: str = "FIXED_POINT") -> tuple[float, float]:
        """Wrap the QEMC circuit resource function with a fixed Trotter-step count.

        :param n_local: Number of spins.
        :param eps_W: Error budget for one implementation of ``W`` or ``W-dagger``.
        :param beta: Inverse temperature for the current annealing step.
        :param arithmetic_type_local: Arithmetic implementation, ``"HYBRID"`` or ``"FIXED_POINT"``.
        :return: Tuple ``(logical_depth, logical_qubits)`` for one QEMC walk application.
        """
        return quantum_walk_qemc_circuit(n_local, eps_W, beta, num_trotter_steps, arithmetic_type_local, k_randomized_grid=k_randomized_grid)

    return _get_annealing_time_quantum_walk(n, eps_TV, betas, spectral_gaps, physical_operation_time, physical_measurement_time, physical_error_rate, circuit_fn, zeno_overlap_probability, arithmetic_type)



def get_one_step_quantum_walk_queries(n: int | float, eps_TV: float, spectral_gap: float, overlap: float = 1.0 / np.e) -> float:
    """Return the expected walk queries for one warm-start spectral-filter step.

    This is the one-step analogue of ``get_annealing_queries_quantum_walks``.
    It reuses the same error split and spectral-filter degree formula, but uses
    the expected number of direct attempts ``1 / overlap`` rather than the
    schedule-level Zeno-rewind overhead ``1 + 1 / overlap``.

    :param n: Number of spins; currently unused but kept for API compatibility.
    :param eps_TV: Desired total-variation distance error.
    :param spectral_gap: Spectral gap of the Markov-chain discriminant matrix.
    :param overlap: Lower bound on the squared overlap between the input and target coherent Gibbs states.
    :return: Expected total number of calls to ``W`` or ``W-dagger``.
    """
    _, _, eps_FLT, _ = split_quantum_error_budget(eps_TV)
    expected_attempts = 1.0 / overlap
    eps_filter = eps_FLT / expected_attempts
    degree_filter = spectral_filter_polynomial_degree(spectral_gap, eps_filter)
    return float(expected_attempts * degree_filter)


def get_annealing_queries_quantum_walks(n: int | float, eps_TV: float, spectral_gaps: list[float], zeno_overlap_probability: float = 1.0 / np.e) -> float:
    """Return the expected number of walk queries in the Zeno-rewind quantum annealing schedule.

    :param n: Number of spins; currently unused but kept for API compatibility.
    :param eps_TV: Desired final total-variation distance error.
    :param spectral_gaps: Spectral gaps along the annealing schedule.
    :param zeno_overlap_probability: Lower bound on the squared overlap used in the Zeno-rewind cost model.
    :return: Expected total number of calls to ``W`` or ``W-dagger``.
    """
    budget = get_quantum_annealing_error_budget(eps_TV, spectral_gaps, zeno_overlap_probability)
    return budget["total_queries"]


def tight_schedule_annealing(n: int | float, beta: float) -> list[float]:
    """
    There ...
    """
    beta = float(beta)
    if beta <= 0.0:
        return []

    current = 0.0
    schedule = []


    def delta_beta(
        n: int | float,
        beta: float | np.ndarray,
    ) -> float | np.ndarray:
        beta_arr = np.asarray(beta, dtype=float)
        step = np.empty_like(beta_arr)
        low_beta = beta_arr < 1.0
        step[low_beta] = np.exp(
            -0.111 * beta_arr[low_beta]
            + 0.615 * beta_arr[low_beta] ** 2
        )
        step[~low_beta] = (
            0.533 * (beta_arr[~low_beta] + 0.286) ** 1.75
        )
        step /= np.sqrt(float(n))
        return float(step) if beta_arr.ndim == 0 else step
    

    while current < beta:
        step = float(delta_beta(n, current))
        if not np.isfinite(step) or step <= 0.0:
            raise ValueError(f"Invalid annealing step: n={n}, beta={current}, step={step}")

        next_beta = current + step

        if current < 1.0 < min(next_beta, beta):
            next_beta = 1.0

        current = min(next_beta, beta)

        if not schedule or not np.isclose(current, schedule[-1]):
            schedule.append(current)

    return schedule


def make_prefix_stable_schedule_generator(
    beta_max: float,
    n_ref: int | float,
    base_schedule_generator,
):
    """Return a schedule generator using one fixed master beta grid.

    :param beta_max: Maximum final beta for which the schedule is needed.
    :param n_ref: Reference n used to generate the master schedule, usually n_plot_max.
    :param base_schedule_generator: Original adaptive schedule generator.
    :return: Function ``schedule(n, beta)`` with beta-prefix stability and no n-dependent node motion.
    """
    beta_max = float(beta_max)
    master_schedule = base_schedule_generator(n_ref, beta_max)

    def schedule(n: int | float, beta: float) -> list[float]:
        beta = float(beta)
        if beta <= 0.0:
            return []

        prefix = [b for b in master_schedule if b < beta and not np.isclose(b, beta)]

        if not prefix or not np.isclose(prefix[-1], beta):
            prefix.append(beta)

        return prefix

    return schedule
